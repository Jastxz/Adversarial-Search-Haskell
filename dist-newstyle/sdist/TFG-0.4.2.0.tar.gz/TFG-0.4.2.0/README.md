# Adversarial-Search-Haskell
Búsqueda de estados en juegos con adversario implementado en Haskell y aplicado a algunos juegos
