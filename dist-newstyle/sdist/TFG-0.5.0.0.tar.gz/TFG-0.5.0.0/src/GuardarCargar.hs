module GuardarCargar
  ( menuCargarPartida,
    cargarPartida,
    guardarPartida,
  )
where

import Data.List
import Data.Matrix
import System.Directory
import Tipos
import Utiles

{- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Funciones constantes
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -}

directorioPartidas :: IO String
directorioPartidas = do
  directorioActual <- getCurrentDirectory
  return $ directorioActual ++ "/Partidas"

menuCargarPartida :: Mundo
menuCargarPartida = (tableroVacio "cargar", "", 0, 0, "", 0, "", False, [["nada"]])

{- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Funciones de trabajo
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -}

cargarPartida :: String -> IO Mundo
cargarPartida juego = undefined --mundo

guardarPartida :: Mundo -> IO Mundo
guardarPartida mundo@(mov@(estado, pos), juego, dif, prof, marca, turno, seleccionado, esMaquina, adicional) = do
  preparaDirectorios
  caminoPartidas <- directorioPartidas
  archivos <- listDirectory caminoPartidas
  let numArchivos = length [archivo | archivo <- archivos, juego `isPrefixOf` archivo]
  let numArchivo = numArchivos + 1
  let nombreArchivo = caminoPartidas ++ "/" ++ juego ++ "_" ++ show numArchivo ++ ".txt"
  let contenidoArchivo = creaContenido mundo
  a <- writeFile nombreArchivo contenidoArchivo
  seHaCreado <- doesFileExist nombreArchivo
  if seHaCreado
    then do
      print "Save file successfully"
      return mundo
    else do
      let parte1 = "No se ha podido crear el guardado de partida con nombre: "
      let parte2 = nombreArchivo ++ " y contenido: " ++ contenidoArchivo
      error $ parte1 ++ parte2

creaContenido :: Mundo -> String
creaContenido mundo@(mov@(estado, pos), juego, dif, prof, marca, turno, seleccionado, esMaquina, adicional) = contenido
  where
    nl = "\n"
    estadoForm = show (toLists estado) ++ nl
    posForm = show pos ++ nl
    juegoForm = juego ++ nl
    difForm = show dif ++ nl
    profForm = show prof ++ nl
    marcaForm = marca ++ nl
    turnoForm = show turno ++ nl
    selForm = seleccionado ++ nl
    maqForm = show esMaquina ++ nl
    adForm | null adicional = "[]" ++ nl
      | otherwise = show adicional ++ nl
    parte1 = estadoForm ++ posForm ++ juegoForm ++ difForm ++ profForm
    parte2 = marcaForm ++ turnoForm ++ selForm ++ maqForm ++ adForm
    contenido = parte1 ++ parte2

{- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Funciones auxiliares
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -}

preparaDirectorios :: IO ()
preparaDirectorios = do
  caminoPartidas <- directorioPartidas
  createDirectoryIfMissing False caminoPartidas